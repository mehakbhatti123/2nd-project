// #include<iostream>
using namespace std;
class STACK
{
public:
    int LEVEL;
    string WORD;
    string CATEGORY;
    int list[200];
    int TOP;
    STACK() 
    {
        LEVEL=0;TOP=-1;
        PUSH(1,"food","pizza");
        PUSH(2,"vehicle","car");
        PUSH(3,"clothes","frock");
        PUSH(4,"vegetables","carrrot");
        PUSH(5,"fruits","apple");

    }
    int IsEmpty()
    {
        return (TOP==-1);
    }
    int IsFull()
    {
        return (TOP==199);
    }
    void PUSH(int l,string w,string c)
{
    if(TOP!=199)
    {
    TOP++;
    list[TOP]=LEVEL;
    }
    else
        cout<<"\n--List is full\n";
}
void CLEAR()
{
    if(TOP!=-1)
    {
    TOP--;
    }
    else 
        cout<<"-List is already empty\n";
}
int POP()
{
    return list[TOP--];
}
int PEEK()
{
    if(TOP!=-1)
        return list[TOP];
    return -1;
}
};

const int MAX_SIZE = 5;
class queue
{
public:
    int LEVEL;
    string WORD;
    string CATEGORY;
    int arr[10];
    int front;
    int rear;
    queue()
    {
        front = -1;
        rear = -1;
        LEVEL=0;
        enqueue(21,"deserts","antarctic");
        enqueue(22,"producers","grasshopper");
        enqueue(23,"consumers","owl");
        enqueue(24,"birds","parrots");
        enqueue(25,"mobiles","iphone");
    }

    int isempty()
    {
        if (front == -1 && rear == -1)
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }
    int isfull()
    {
        if (front == 0 && rear == MAX_SIZE - 1)
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }
    void enqueue(int l,string w,string c)
    {if (isfull())
        {
            cout << "queue overflow" << endl;
        }
        else if (isempty())
        {
            rear++;  front++;
            arr[rear] = LEVEL;
        }
        else
        {
            rear++;
            arr[rear] = LEVEL;
        }
    }
    void dequeue()
    {
        // if (front == -1 && rear == -1)
        if (isempty())
        {
            cout << "queue is empty" << endl;
        }
        else if (front == rear)
        {
            front = -1;
            rear = -1;
        }
        else
        {
            front++;
        }
    }
    int peek()
    {
        if (isempty())
        {

            cout << "Queue is empty" << endl;
        }
        else
        {
            return arr[front];
        }
    }
};