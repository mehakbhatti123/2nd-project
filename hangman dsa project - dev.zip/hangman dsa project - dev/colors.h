#include<iostream>
#include<iomanip>
#include<cstdlib>
#include<windows.h>
using namespace std;

enum textclr    
{
    BLACK=30, RED, GREEN, YELLOW, BLUE, MAGENTA, CYAN, WHITE
};

enum backgroundclr
{
    BG_BLACK=40, BG_RED, BG_GREEN, BG_YELLOW, BG_BLUE, BG_MAGENTA, BG_CYAN, BG_WHITE
};

class COLOR
{
public:
static void changeclr(textclr t, backgroundclr b)
{
    cout<<"\033["<<static_cast<int>(t)<<"m";
    cout<<"\033["<<static_cast<int>(b)<<"m";
}
};

class TEXT
{
public:
    static void Boldtext()
{
    cout<<"\033[1m";
}
static void Normaltext()
{
    cout<<"\033[0m";
}
};