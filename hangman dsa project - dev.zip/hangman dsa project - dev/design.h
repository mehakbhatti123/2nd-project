#include"colors.h"
using namespace std;
class DESIGN
{
public:
	
    static void main_menu_Design()
    {
    cout<<setw(68)<<setfill(' ')<<""<<setw(44)<<setfill('*')<<""<<endl;
    cout<<setw(69)<<setfill(' ')<<"*"<<setw(43)<<setfill(' ')<<"*"<<endl;
    cout<<setw(68)<<setfill(' ')<<""<<setw(14)<<setfill('-')<<""<<"M A I N  M E N U"<<setw(14)<<setfill('-')<<""<<endl;
    cout<<setw(69)<<setfill(' ')<<"*"<<setw(43)<<setfill(' ')<<"*"<<endl;
    cout<<setw(68)<<setfill(' ')<<""<<setw(44)<<setfill('*')<<""<<endl<<endl<<endl;
    }
    static void admin_menu_Design()
    {
    cout<<setw(68)<<setfill(' ')<<""<<setw(44)<<setfill('*')<<""<<endl;
    cout<<setw(69)<<setfill(' ')<<"*"<<setw(43)<<setfill(' ')<<"*"<<endl;
    cout<<setw(68)<<setfill(' ')<<""<<setw(13)<<setfill('-')<<""<<"A D M I N  M E N U"<<setw(13)<<setfill('-')<<""<<endl;
    cout<<setw(69)<<setfill(' ')<<"*"<<setw(43)<<setfill(' ')<<"*"<<endl;
    cout<<setw(68)<<setfill(' ')<<""<<setw(44)<<setfill('*')<<""<<endl<<endl<<endl;
    }
    static void gamer_menu_Design()
    {
    cout<<setw(68)<<setfill(' ')<<""<<setw(44)<<setfill('*')<<""<<endl;
    cout<<setw(69)<<setfill(' ')<<"*"<<setw(43)<<setfill(' ')<<"*"<<endl;
    cout<<setw(68)<<setfill(' ')<<""<<setw(13)<<setfill('-')<<""<<"G A M E R  M E N U"<<setw(13)<<setfill('-')<<""<<endl;
    cout<<setw(69)<<setfill(' ')<<"*"<<setw(43)<<setfill(' ')<<"*"<<endl;
    cout<<setw(68)<<setfill(' ')<<""<<setw(44)<<setfill('*')<<""<<endl<<endl<<endl;
    }
    static void sign_up_Design()
    {
    cout<<setw(68)<<setfill(' ')<<""<<setw(44)<<setfill('*')<<""<<endl;
    cout<<setw(69)<<setfill(' ')<<"*"<<setw(43)<<setfill(' ')<<"*"<<endl;
    cout<<setw(68)<<setfill(' ')<<""<<setw(16)<<setfill('-')<<""<<"S I G N  U P"<<setw(15)<<setfill('-')<<""<<endl;
    cout<<setw(69)<<setfill(' ')<<"*"<<setw(43)<<setfill(' ')<<"*"<<endl;
    cout<<setw(68)<<setfill(' ')<<""<<setw(44)<<setfill('*')<<""<<endl<<endl<<endl;
    }
    static void sign_in_Design()
    {
    cout<<setw(68)<<setfill(' ')<<""<<setw(44)<<setfill('*')<<""<<endl;
    cout<<setw(69)<<setfill(' ')<<"*"<<setw(43)<<setfill(' ')<<"*"<<endl;
    cout<<setw(68)<<setfill(' ')<<""<<setw(16)<<setfill('-')<<""<<"S I G N  I N"<<setw(15)<<setfill('-')<<""<<endl;
    cout<<setw(69)<<setfill(' ')<<"*"<<setw(43)<<setfill(' ')<<"*"<<endl;
    cout<<setw(68)<<setfill(' ')<<""<<setw(44)<<setfill('*')<<""<<endl<<endl<<endl;
    }
    static void Admin_Design()
    {
    cout<<setw(68)<<setfill(' ')<<""<<setw(44)<<setfill('*')<<""<<endl;
    cout<<setw(69)<<setfill(' ')<<"*"<<setw(43)<<setfill(' ')<<"*"<<endl;
    cout<<setw(68)<<setfill(' ')<<""<<setw(18)<<setfill('-')<<""<<"A D M I N"<<setw(17)<<setfill('-')<<""<<endl;
    cout<<setw(69)<<setfill(' ')<<"*"<<setw(43)<<setfill(' ')<<"*"<<endl;
    cout<<setw(68)<<setfill(' ')<<""<<setw(44)<<setfill('*')<<""<<endl<<endl<<endl;
    }

    static void CoverPg() 
    {
        system("cls");
    cout<<endl<<endl<<endl<<endl<<endl<<endl;
    COLOR::changeclr(YELLOW,BG_BLACK);
	cout <<"\t \t \t \t \t \t*****************************************************************\n";
	cout <<"\t \t \t \t \t \t*****************************************************************\n";
    cout <<"\t \t \t \t \t \t**  _    _                                                     **\n";
    cout <<"\t \t \t \t \t \t** | |  | |                                            ____    **\n";
    cout <<"\t \t \t \t \t \t** | |__| | __ _ _ __   __ _ _ __ ___   __ _ _ __     |   (O)  **\n";
    cout <<"\t \t \t \t \t \t** |  __  |/ ` | ' \\ / `   | ' ` _ \\ / ` | ' \\ \\  \\   |   /|\\  **\n";
    cout <<"\t \t \t \t \t \t** | |  | | (_| | | | | (_| | | | | | | (_| | | | |   |    |   **\n";
    cout <<"\t \t \t \t \t \t** |_|  |_|\\__,_|_| |_|\\__, |_| |_| |_|\\__,_|_| |_|   |   / \\  **\n";
    cout <<"\t \t \t \t \t \t**                     __/ |                                   **\n";
    cout <<"\t \t \t \t \t \t**                    |___/                                    **\n";
    cout <<"\t \t \t \t \t \t**                                                             **\n";
    cout <<"\t \t \t \t \t \t*****************************************************************\n";
    cout <<"\t \t \t \t \t \t*****************************************************************\n";
    char a;
    cin>>a;
}
};
