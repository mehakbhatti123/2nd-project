#include<iostream>
#include"design.h"
using namespace std;

class NODE
{
public:
    short ID;
    string NAME;
    short LEVEL;
    string PASSWORD;
    NODE* next;

    NODE(short ID,string NAME,string PASSWORD,short LEVEL, NODE* ptr = NULL)
    {
        this->ID=ID;
        this->NAME=NAME;
        this->PASSWORD=PASSWORD;
        this->LEVEL=LEVEL;
        next=ptr;
    }
};
class GamerList
{
public:
    NODE* HEAD;

    GamerList()
    {
        HEAD=0;
        AddToHead(37,"Abdul Rehman","ab123",20);
        AddToHead(123,"Mazia zafar","mz123",10);
        AddToHead(148,"masham shahzad","ms123",4);
        AddToHead(42,"izza arshad","ia123",2);
    }
    ~GamerList()
    {
        for(NODE* p;!IsEmpty();HEAD=p)
        {
            p=HEAD->next;
            delete HEAD;
        }   
    }

    int IsEmpty()
    {
       return HEAD == NULL;
    }
    void AddToHead(short no, string grade,string p,short level)
    {
        HEAD=new NODE(no,grade,p,level,HEAD);
    }

    void AddToTail(short no, string grade,string ps,short level)
    {
        NODE* temp;
        for(temp=HEAD; temp->next!=NULL; temp=temp->next);
        NODE* p=new NODE(no,grade,ps,level);
        temp->next =p;
    }
    
    void DeleteFromHead()
    {
        if(HEAD->next!=NULL)
        {
            NODE* temp=HEAD;
            HEAD=HEAD->next;
            delete temp;
        }
        else
        {
            delete HEAD;
            HEAD=NULL;
        }
    }
    void DeleteFromTail()
    {
        if(IsEmpty()) return;
        NODE*temp=HEAD;
        for(;temp->next->next!=NULL;temp=temp->next);
        temp->next=NULL;
    }
    int DeleteElement(short key)
    {
        int found=1;
        if(!SearchElement(key))
        {
            found=0;
        }
        else
        {
           NODE* current=HEAD;
           NODE* previous=NULL;
           while(current->ID!=key)
           {
                previous=current;
                current=current->next;
           }
           if(previous==NULL)
                DeleteFromHead();
            else if (current->next==NULL)
                DeleteFromTail();
            else
            {
                previous->next=current->next;
                delete current;
            }
        }
        return found;
    }
    int SearchElement(short key)
    {
        int found=0;
        for(NODE* temp=HEAD;temp!=NULL;temp=temp->next)
            if(temp->ID==key)
            {   found=1;
                break;
            }
        return found;
    }
    short GetLevel(short id)
    {
        short found=1;
        for(NODE* temp=HEAD;temp!=NULL;temp=temp->next)
            if(temp->ID==id)
            {   
                found=temp->LEVEL;
                break;
            }
        return found;
    }
    int checkPassword(short key,string p)
    {
        int found=0;
        for(NODE* temp=HEAD;temp!=NULL;temp=temp->next)
            if(temp->ID==key && temp->PASSWORD==p)
            {
                found=1;
                break;
            }
        return found;
    }
    int UpdateLevel(short key,short lvl)
    {
        int found=0;
        for(NODE* temp=HEAD;temp!=NULL;temp=temp->next)
            if(temp->ID==key)
            {   temp->LEVEL=lvl;
                found=1;
                break;
            }
        return found;
    }
    int DisplayAll()
    {
        system("cls");
        cout<<endl<<endl;
        TEXT::Boldtext();
        COLOR::changeclr(GREEN,BG_BLACK);
        cout<<"ID"<<"\t "<<"NAME"<<"\t \t \t"<<"PASSWORD"<<"\t"<<"LEVEL"<<endl;
        int found=0;
        if(HEAD!=NULL)
        {
            TEXT::Normaltext();
            COLOR::changeclr(YELLOW,BG_BLACK);
            for(NODE* temp=HEAD; temp!=NULL; temp=temp->next)
                cout<<temp->ID<<"\t"<<temp->NAME<<"\t \t"<<temp->PASSWORD<<"\t \t"<<temp->LEVEL<<endl;
            found=1;
        }
        cout<<endl<<endl;
        return found;
    }
    void DisplayGamer(short id)
    {
        cout<<endl;
        TEXT::Boldtext();
        COLOR::changeclr(GREEN,BG_BLACK);
        cout<<"ID"<<"\t "<<"NAME"<<"\t \t \t"<<"PASSWORD"<<"\t"<<"LEVEL"<<endl;
         for(NODE* temp=HEAD;temp!=NULL;temp=temp->next)
            if(temp->ID==id)
            {
                TEXT::Normaltext();
                COLOR::changeclr(YELLOW,BG_BLACK);
                cout<<temp->ID<<"\t"<<temp->NAME<<"\t \t"<<temp->PASSWORD<<"\t \t"<<temp->LEVEL<<endl;
                break;
            }
        cout<<endl<<endl;
    }
};