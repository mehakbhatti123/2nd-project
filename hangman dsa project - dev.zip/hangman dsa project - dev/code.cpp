#include"validation.h"
#include<fstream>
using namespace std;
void Gamer_menu();
void Admin_menu();
int Sign_up();
int Sign_in();
class Menu
{
public:
    static void main_menu()
    {
        system("cls");
        cout<<endl<<endl;
        DESIGN::main_menu_Design();
    cout<<endl<<endl<<endl;
    short choice;
    cout<<"\t* * * * * * * * * * * * * * * * * * * *"<<endl;
    cout<<"\t| Option 1. Admin                     |"<<endl
        <<"\t- - - - - - - - - - - - - - - - - - - -"<<endl
        <<"\t| Option 2. Gamer                     |"<<endl
        <<"\t- - - - - - - - - - - - - - - - - - - -"<<endl
        <<"\t| Option 0. Exit                      |"<<endl
        <<"\t- - - - - - - - - - - - - - - - - - - -"<<endl;
    cout<<"\t| Enter Your choice:                  |\b\b\b\b\b\b\b\b\b\b\b\b";choice=Validation::GetNoFromUser(2);
    cout<<"\t* * * * * * * * * * * * * * * * * * * *"<<endl;
    cout<<endl<<endl<<"\t";
    system("pause");
    switch (choice)
    {
    case 1:
        {
            Admin_menu();
            break;
        }
    case 2:
        {
            Gamer_menu();
            break;
        }
    case 0:
        {
            cout<<endl<<endl<<".....You exited  (*_^).....";   exit(0);
        }
    default:
        {
            cout<<endl<<endl<<"......Wrong input......\n";
            system("pause");
            Menu::main_menu();
            break;
        }
    }
    }
};

int main()
{
    COLOR::changeclr(YELLOW,BG_BLACK);
    DESIGN::CoverPg();
    Menu:: main_menu();
    return 0;
}

void Gamer_menu()
{
    system("cls");
    DESIGN::gamer_menu_Design();
    cout<<endl<<endl<<endl;
    short choice;
    cout<<"\t* * * * * * * * * * * * * * * * * * * *"<<endl;
    cout<<"\t| Option 1. Sign Up                   |"<<endl
        <<"\t- - - - - - - - - - - - - - - - - - - -"<<endl
        <<"\t| Option 2. Sign In                   |"<<endl
        <<"\t- - - - - - - - - - - - - - - - - - - -"<<endl
        <<"\t| Option 9. Main Menu                 |"<<endl
        <<"\t- - - - - - - - - - - - - - - - - - - -"<<endl
        <<"\t| Option 0. Exit                      |"<<endl
        <<"\t- - - - - - - - - - - - - - - - - - - -"<<endl;
    cout<<"\t| Enter Your choice:                  |\b\b\b\b\b\b\b\b\b\b\b\b";choice=Validation::GetNoFromUser(2);
    cout<<"\t* * * * * * * * * * * * * * * * * * * *"<<endl;
    cout<<endl<<endl<<"\t";
    system("pause");
    switch (choice)
    {
    case 1:
        {
            system("cls");
            DESIGN::sign_up_Design();
            cout<<endl<<endl;
            short t;
            t=Sign_up();
            cout<<endl;
            system("pause");
            Game(t);
            break;
        }
    case 2:
        {
            system("cls");
            DESIGN::sign_in_Design();
            cout<<endl<<endl;
            short t;
            t=Sign_in();
            Game(t);
            break;
        }
    case 0:
        {
            cout<<endl<<endl<<".....You exited  (*_^).....";   exit(0);
        }
    case 9:
        {
            Menu::main_menu();
        }
    default:
        {
            cout<<endl<<endl<<"......Wrong input......\n";
            system("pause");
            Gamer_menu();
            break;
        }
    }
}
void Admin_menu()
{
    system("cls");
    DESIGN::admin_menu_Design();
   cout<<endl<<endl<<endl;
    short choice;
    cout<<"\t* * * * * * * * * * * * * * * * * * * *"<<endl;
    cout<<"\t| Option 1. Add Gamer                 |"<<endl
        <<"\t- - - - - - - - - - - - - - - - - - - -"<<endl
        <<"\t| Option 2. Search Gamer              |"<<endl
        <<"\t- - - - - - - - - - - - - - - - - - - -"<<endl
        <<"\t| Option 3. Delete Gamer              |"<<endl
        <<"\t- - - - - - - - - - - - - - - - - - - -"<<endl
        <<"\t| Option 4. Display All Gamers        |"<<endl
        <<"\t- - - - - - - - - - - - - - - - - - - -"<<endl
        <<"\t| Option 9. Main Menu                 |"<<endl
        <<"\t- - - - - - - - - - - - - - - - - - - -"<<endl
        <<"\t| Option 0. Exit                      |"<<endl
        <<"\t- - - - - - - - - - - - - - - - - - - -"<<endl;
    cout<<"\t| Enter Your choice:                  |\b\b\b\b\b\b\b\b\b\b\b\b";choice=Validation::GetNoFromUser(2);
    cout<<"\t* * * * * * * * * * * * * * * * * * * *"<<endl;
    cout<<endl<<endl<<"\t";
    system("pause");
    switch (choice)
    {
    case 1:
        {
            system("cls");
            DESIGN::Admin_Design();
            Sign_up();
            Admin_menu();
            break;
        }
    case 2:
        {
            system("cls");
            DESIGN::Admin_Design();
            short id;
            cout<<"---Enter Gamer ID:\t";
            id=Validation::GetNoFromUser(3);
            if(!(GL.SearchElement(id)))
            {
                cout<<endl<<".... There is no such id ....\n";
            }
            else
            {
                GL.DisplayGamer(id);
            }
            system("pause");
            Admin_menu();
            break;
        }
    case 3:
        {
            system("cls");
            DESIGN::Admin_Design();
            short id;
            cout<<"---Enter Gamer ID:\t";
            id=Validation::GetNoFromUser(3);
            if(GL.DeleteElement(id))
            {
                cout<<"\n... Gamer Deleted (*_^) ...\n";
            }
            else
            {   
                cout<<"\n...Gamer can't be Deleted...\n";
            }
            system("pause");
            Admin_menu();
            break;
        }
    case 4:
        {
            system("cls");
            DESIGN::Admin_Design();
            GL.DisplayAll();
            system("pause");
            Admin_menu();
            break;
        }
    case 0:
        {
            cout<<endl<<endl<<".....You exited (*_^) .....";   exit(0);
        }
    case 9:
        {
            Menu::main_menu();
        }
    default:
        {
            cout<<endl<<endl<<"......Wrong input......\n";
            system("pause");
            Admin_menu();
            break;
        }
    }
}
int Sign_up()
{
    int id;
    string name="\0";
    string pswrd="\0";
    cout<<endl<<endl;
    cout<<"\t\t\t---N e w  G a m e r---\n\n\n";
    cout<<"---Enter Gamer ID:\t";
    id=Validation::GetNoFromUser(3);
    if(GL.SearchElement(id))
    {
        cout<<endl;
        cout<<".... This user already exists ....\n";
        system("pause");
        Sign_up();
    }
    else
    {
    cout<<endl;
    cout<<"---Enter Gamer name:\t"; 
    name=Validation::GetStringFromUser(20);
    cout<<endl; 
    cout<<"---Enter Gamer Password:\t"; 
    pswrd=Validation::GetPasswordFromUser(10);
    cout<<endl;
    GL.AddToHead(id,name,pswrd,1); 
    cout<<"\n\n... Gamer is added successfully (*_^)...\n\n";
    ofstream outputfile("records.txt");
    outputfile.is_open();
    outputfile<<id<<endl<<name<<endl<<pswrd<<endl;
    outputfile.close();
    return id;
    }
    return -1;
}
int Sign_in()
{
    int id;
    string pswrd="\0";
    cout<<endl<<endl; 
    cout<<"---Enter Gamer ID:\t"; 
    id=Validation::GetNoFromUser(3);
    if(!(GL.SearchElement(id)))
    {
        cout<<endl; 
        cout<<"... There is no such id ...\n";
        system("pause");
        Gamer_menu();
    }
    else
    {
    cout<<endl; 
    cout<<"---Enter Gamer Password:\t"; 
    pswrd=Validation::GetPasswordFromUser(10);
    cout<<endl;
    if(GL.checkPassword(id,pswrd))
    {   
        cout<<"\n\n... correct Password (*_^) ...\n\n";
        system("pause");
        return id;
    }
    else
    {
        cout<<"\n\n... wrong Password ...\n\n";
        system("pause");
        Gamer_menu();
    }
    }
    return -1;
}