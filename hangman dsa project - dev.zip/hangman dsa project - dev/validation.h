#include<iostream>
#include<conio.h>
#include"game.h"
using namespace std;
class Validation
{
public:
    static short GetNoFromUser(short len)
    {
        char strNum[12];
        char ch;
        short i=0;
        while(i<len)
        {
            ch=getch();
            if(ch>=48&&ch<=57)
            {
                cout<<ch;
                strNum[i]=ch;
                i++;
            }
            if(ch=='\r')
            {
                if(i!=0)
                break;
            }
            if(ch=='\b')
            {
                cout<<"\b \b"; 
                i--;
            }
        }
        cout<<"\n";
        strNum[i]='\0';
        return atoi(strNum);
    }
    static string GetStringFromUser(short len)
    {
        char strNum[256];
        char ch;
        short i=0;
        while(i<len)
        {
            ch=getch();
            if((ch>=48&&ch<=57)||(ch>='A'&&ch<='Z')||(ch>='a'&&ch<='z')||(ch==32))
            {
                cout<<ch;
                strNum[i]=ch;
                i++;
            }
            if(ch=='\r')
            {   if(i!=0)
                break;
            }               
            if(ch=='\b')
            {
                cout<<"\b \b"; 
                i--;
            }
        }
        cout<<"\n";
        strNum[i]='\0';
        return strNum;
    }
    static string GetPasswordFromUser(short len)
    {
        char strNum[256];
        char ch;
        short i=0;
        while(i<len)
        {
            ch=getch();
            if((ch>=48&&ch<=57)||(ch>='A'&&ch<='Z')||(ch>='a'&&ch<='z')||(ch==32))
            {
                cout<<"*";
                strNum[i]=ch;
                i++;
            }
            if(ch=='\r')
            {   if(i!=0)
                break;
            }               
            if(ch=='\b')
            {
                cout<<"\b \b"; 
                i--;
            }
        }
        cout<<"\n";
        strNum[i]='\0';
        return strNum;
    }
    static char GetCharFromUser(short len)
    {
        char ch;
        short i=0;
        while(i<2)
        {
            ch=getch();
            if(ch>='a'&&ch<='z')
            {
                cout<<ch;
                i++;
            }
            if(ch=='\r')
            {   if(i!=0)
                break;
            }               
            if(ch=='\b')
            {
                cout<<"\b \b"; 
                i--;
            }
        }
        cout<<"\n";
        return ch;
    }
    
    
};
