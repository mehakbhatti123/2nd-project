#include"gamerlist.h"
#include"stackque.h"
#include<cstring>
#include<string>
using namespace std;
GamerList GL;
STACK s;
queue q;
struct ArrayElement
{
    short Level;
    string Category;
    string Word;
};
class LEVEL
{
public:
    
    static const int maxSize = 40;  // Specify the maximum size of the array
    ArrayElement elements[maxSize];
    int currentSize;  // Keep track of the current size of the array

    // Constructor
    LEVEL() : currentSize(0) 
    {
    insert(1,"food","pizza");
    insert(2,"vehicle","car");
    insert(3,"clothes","frock");
    insert(4,"vegetables","carrrot");
    insert(5,"fruits","apple");
    insert(6,"furniture","chair");
    insert(7,"stationary","pen");
    insert(8,"games","bubbleshooter");
    insert(9,"pets","cat");
    insert(10,"cutlery","knife");
    insert(11,"toys","ball");
    insert(12,"animals","lion");
    insert(13,"watertransport","ship");
    insert(14,"plants","cactus");
    insert(15,"microorganisms","fungi");
    insert(16,"books","computerscience");
    insert(17,"seas","redsea");
    insert(18,"oceans","pacific");
    insert(19,"mountains","karakoram");
    insert(20,"footwear","sandles");
    insert(21,"deserts","antarctic");
    insert(22,"producers","grasshopper");
    insert(23,"consumers","owl");
    insert(24,"birds","parrots");
    insert(25,"mobiles","iphone");
    insert(26,"cosmetics","lipstick");
    insert(27,"currency","dollars");
    insert(28,"music","songs");
    insert(29,"countries","america");
    insert(30,"companies","amazon");
    }

    // Function to insert an element into the array list
    void insert(int value, const string& str1, const string& str2) 
    {
            elements[currentSize].Level = value;
            elements[currentSize].Category = str1;
            elements[currentSize].Word = str2;
            ++currentSize;
    }

    // Function to search for an element by int value
    ArrayElement searchByLevel(int value) 
    {
        ArrayElement e;
        for (int i = 0; i < currentSize; ++i) 
        {
            if (elements[i].Level == value) 
            {
                return elements[i];
            }
        }
        return e;
    }

    // Function to display all elements in the array list
    void DisplayAll()
    {
        cout<<"Level \t Category \t Word\n";
        for (int i = 0; i < currentSize; ++i) 
        {
            cout<< elements[i].Level<<"\t"<< elements[i].Category<<"\t\t"<< elements[i].Word << endl;
        }
    }
};
void DisplayShape(int lives)
{
if(lives==5) return;
cout<<" ________";
cout<<endl;
cout<<"|       }";
cout<<endl;
    if(lives==4) return;
cout<<"|     ('_')";
cout<<endl;
    if(lives==3) return;
cout<<"|       |";
cout<<endl;
    if(lives==2) return;
cout<<"|     / | \\";
cout<<endl;
cout<<"|    /  |  \\";
cout<<endl;
    if(lives==1) return;
cout<<"|      / \\";
cout<<endl;
cout<<"|    /     \\";
cout<<endl;
}
void Game(short id)
{
    short lvl;
    LEVEL lvl1;
    short sz;
again:
    ArrayElement ae;
    int lives=5;
    lvl=GL.GetLevel(id);
    ae=lvl1.searchByLevel(lvl);
    string b=ae.Word;
    sz=b.size()+1;
    //real word
    char word[sz];
    strcpy(word, b.c_str());
    int wordLength=sz;
    //creating temp array in which inputted values will be stored
    char temp[wordLength];
    // temporarily storing _ in array
    for(int i=0;i<wordLength;i++)
        temp[i]='_';
    temp[wordLength]='\0';
    char letter;
    int input;
    while (lives>=0)
    {
        system("cls");
        cout<<endl;
        // displaying shape
        DisplayShape(lives);
        cout<<endl<<endl;

        // displaying level
        cout<<"-Level: "<<lvl;
        cout<<endl<<endl;

        // displaying remaining lives
        cout<<"-Lives: "<<lives<<endl<<endl;

        // displaying word category
        cout<<"-Word hint: "<<ae.Category<<endl<<endl;

        // displaying guessed word
        cout<<"-Guessed word: ";
        for(int i=0;i<wordLength-1;i++)
            cout<<temp[i]<<" ";
        cout<<endl<<endl;

        // checking if lives left or not to terminate loop
        if(lives==0)
        {   
            cout<<"... Out of lives ..."<<endl<<endl;
            cout<<"-Do you want to continue game (1 for yes)? ";
            cin>>input;
            if(input == 1)
                goto again;
            goto endouterloop;
        }

        // inputting letter
        cout<<endl<<"-Enter letter: ";
        cin>>letter;

        // checking if letter is present in word or not
        bool found=false;
        for(int i=0;i<wordLength-1;i++)
        {
            if(letter==word[i])
            {
                temp[i]=letter;
                found=true;                
            }
        }

        // checking if all letters found or not
        bool AllFound=true;
        for(int i=0;i<wordLength-1;i++)
        {
            if(temp[i]=='_')
            {
                AllFound=false;
                break;
            }
        }

        // displaying successful msg if all letters are found
        if (AllFound == 1) 
        {
            cout<<"\n\n... Congratulations! You guessed the word: "<<ae.Word<<"  (*_^) ..."<<endl<<endl;
            // updating level of gamer
            ++lvl;
            GL.UpdateLevel(id,lvl);
            cout<<"-Do you want to continue game (1 for yes)? ";
            cin>>input;
            if(input == 1)
                goto again;
            goto endouterloop;
            break;
        }

        //decrementing lives if word is not found
        if(!found)
        lives--;
    }

endouterloop: 
    char a;
}